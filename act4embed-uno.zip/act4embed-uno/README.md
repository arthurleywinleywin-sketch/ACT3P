# Gas & Vibration Monitor - Raspberry Pi 5 + Arduino Uno + FastAPI
Activity No. 4: Interfacing Gas and Vibration Sensor with Website

**MQ-2 gas sensor + SW-420 vibration sensor + LED + buzzer are all wired to an Arduino Uno.**
The Uno is plugged into the Raspberry Pi 5 with a USB cable. The Pi runs the website (FastAPI),
decides when to alarm, e-mails the alerts and logs the history. (This replaces the ESP32 + Wi-Fi version.)

    MQ-2, SW-420, LED, buzzer --> Arduino Uno --USB serial--> Raspberry Pi 5 (app.py) --> browser / e-mail

## 1. Wiring (Arduino Uno)
| Part | Connect to |
|---|---|
| MQ-2 VCC / GND | Uno 5V / GND |
| MQ-2 AO | Uno **A0** (direct, no voltage divider: the Uno ADC is 5 V) |
| SW-420 VCC / GND | Uno 5V / GND |
| SW-420 DO | Uno **D2** |
| LED long leg | Uno **D8** through a 330 ohm resistor; short leg -> GND |
| Active buzzer + | Uno **D9**; buzzer - -> GND |

The Uno is powered by the USB cable from the Pi (that also powers the MQ-2 heater).
A big/loud buzzer needs a transistor; a small active buzzer is fine on a pin.

## 2. Upload the Arduino sketch (once)
Open `arduino/sensor_node/sensor_node.ino` in the Arduino IDE, Board = "Arduino Uno", Upload.
No libraries needed. Close the Serial Monitor afterwards (only one program can use the port).
If the vibration alarm is always on, set `VIB_ACTIVE_HIGH = false` in the sketch (some SW-420 modules are reversed)
or turn the blue potentiometer on the module.

## 3. Install on the Raspberry Pi 5 (Raspberry Pi OS Bookworm)
    sudo apt update && sudo apt install -y python3-venv
    cd act4embed-uno
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    sudo usermod -aG dialout $USER      # allow reading the USB serial port, then log out and back in
    ls /dev/ttyACM*                     # the Uno usually shows up as /dev/ttyACM0

## 4. Run
    python app.py
Open `http://<pi-ip>:5000` on a laptop/phone on the same Wi-Fi (`hostname -I` shows the IP).
Stop with Ctrl+C. Do not run two copies at once (the second cannot open the serial port).
`config.py` has `SERIAL_PORT = "auto"`; set it to `"/dev/ttyACM0"` if the Uno is not found.

Test on a normal PC first: with no Arduino plugged in it switches to SIMULATION mode automatically
(or set `SIMULATE = True` in config.py) and shows test buttons in Settings.
On the Pi it never simulates: an unplugged Uno is shown as an error on the dashboard.

## Everything in VS Code on the Raspberry Pi 5
Open the `act4embed-uno` folder in VS Code on the Pi (File > Open Folder). Then use **Terminal > Run Task...**:
1. `1. Setup: create venv + install Python packages` (once). Then choose the `venv` interpreter if VS Code asks.
2. `2. Arduino: install arduino-cli + Uno core (once)` (needs internet).
3. Plug in the Uno, run `4. Arduino: upload sketch to the Uno`. (`3. compile` only checks the sketch.)
   Stop app.py first: it holds the USB port, and the upload cannot use it at the same time.
4. Press **F5** (Run Gas & Vibration Monitor) to start the dashboard, then open `http://localhost:5000` on the Pi
   or `http://<pi-ip>:5000` from another device.
Also run once in the VS Code terminal: `sudo usermod -aG dialout $USER`, then log out and back in.
If you prefer, you can still upload the sketch with the Arduino IDE instead of tasks 2 and 4.

## 5. Email alerts
1. Google Account -> Security -> 2-Step Verification -> **App passwords** -> create one
   (Gmail does not accept the normal account password for SMTP).
2. Open the dashboard -> **Settings** -> turn on email alerts, enter the sender address, the receiver address
   and the app password. (It is saved in `data/email.json`, readable only by you. You can also set the
   `SMTP_PASSWORD` environment variable instead.)
3. Press "Send test email".

The e-mails contain exactly:
- `Vibration sensor detected, PLEASE BE ALERT`
- `Gas sensor detected, PLEASE BE ALERT`

Each sensor has its own cooldown (`EMAIL_COOLDOWN`, 5 min), so a vibration e-mail never hides a gas e-mail.
The receiver address is only an address: its password is never needed.

## 6. Calibrating the MQ-2 (optional)
Let the sensor warm up (`WARMUP_SECONDS`, 2 min; longer is better), then press **Calibrate** on the Live page in clean
air. It records 30 s and shows the mean as the clean-air baseline. (The ESP32 version did this from the Serial Monitor.)
The alarm level is set on the dashboard (default 400 of 1023).

## 7. Pages
- `/` dashboard   - `/history` logs, chart, alert log, CSV download   - `/settings`
- `/data` live JSON   - `/control` (POST) button commands

Data is stored in `data/sensor.db` (SQLite). Delete the `data` folder to start fresh.

## Serial protocol (for reference)
- Uno -> Pi, every 250 ms: `D,<gas 0-1023>,<vibration 0/1>,<uptime seconds>`
  (vibration = 1 if the SW-420 pulsed since the last line; a hardware interrupt catches very short pulses)
- Pi -> Uno: `O<led><buzzer>`, e.g. `O10` = LED on, buzzer off. Sent on every change and as a 0.5 s heartbeat.
The Uno only measures and switches the outputs; all alarm logic (arming, reset, mute, hold times) stays in `app.py`.

## Troubleshooting
| Symptom | Fix |
|---|---|
| "No Arduino found" | Check the USB cable, `ls /dev/ttyACM*`, or set `SERIAL_PORT` in config.py |
| "Permission denied: /dev/ttyACM0" | `sudo usermod -aG dialout $USER`, then log out and in |
| "port busy" / "could not open port" | Close the Arduino Serial Monitor, and stop any other copy of app.py (`pkill -f app.py`) |
| "No data from the Arduino yet" | The sketch is not uploaded, or its BAUD differs from `SERIAL_BAUD` in config.py |
| Gas value always 0 or 1023 | Check the A0 wire and the MQ-2 VCC/GND |
| Vibration always on/off | Turn the SW-420 potentiometer; if inverted set `VIB_ACTIVE_HIGH = false` in the sketch |
| LED/buzzer do not react | Check D8 / D9 wiring and polarity; try Settings -> test buttons / LED and buzzer "on" |
| MQ-2 reads high at first | Normal. It needs a warm-up (allow several minutes for stable readings) |
| The warm-up starts again after restarting app.py | Normal: the Uno restarts whenever the serial port is opened |
| Page does not open from PC | Same network? Use the Pi IP, port 5000, `http://` not https |
| Email failed | Use an App Password; check the addresses in Settings and the internet connection |

## What changed from the ESP32 version
- `mq2_esp32/mq2_esp32.ino` (Wi-Fi + HTTP) is replaced by `arduino/sensor_node/sensor_node.ino` (USB serial).
  No Wi-Fi name/password or server IP is needed any more.
- `app.py`: removed the `/api/esp32` endpoint and the gpiozero code; added a serial reader (pyserial). The SW-420, LED
  and buzzer moved from the Pi GPIO pins to the Uno. Clean-air calibration is now a button on the Live page.
- `config.py`: pin/SPI/ESP32 settings replaced by `SERIAL_PORT`, `SERIAL_BAUD`, `SERIAL_TIMEOUT`, `ADC_REF_VOLTS`.
- The alert e-mails now use the exact wording above, with a separate cooldown per sensor.
