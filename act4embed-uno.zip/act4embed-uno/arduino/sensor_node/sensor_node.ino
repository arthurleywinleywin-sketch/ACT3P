/*
  Arduino Uno sensor node  ->  act4embed dashboard (FastAPI on the Raspberry Pi 5, USB cable)

  WIRING (the Uno is powered from the Pi over the same USB cable)
    MQ-2 module   VCC -> 5V      GND -> GND      AO -> A0     (no voltage divider: the Uno ADC is 5 V)
    SW-420 module VCC -> 5V      GND -> GND      DO -> D2     (D2 = interrupt 0, catches very short pulses)
    LED           D8 -> 330 ohm resistor -> LED long leg ; short leg -> GND
    Buzzer        D9 -> active buzzer (+) ; buzzer (-) -> GND (an active buzzer draws ~20 mA, fine for a pin;
                  for a big/loud buzzer use a transistor)

  PROTOCOL (USB serial, 115200 baud, one text line each)
    Uno -> Pi, every 250 ms :  D,<gas 0-1023>,<vibration 0/1>,<uptime seconds>
                               gas = average of many ADC readings, vibration = 1 if the SW-420 pulsed since the last line
    Pi -> Uno               :  O<led><buzzer>      e.g. "O10" = LED on, buzzer off
  The Pi (app.py) decides when to alarm. The Uno only measures and switches the LED / buzzer.

  Upload: Arduino IDE -> Board "Arduino Uno" -> pick the port -> Upload. No libraries needed.
  Close the Serial Monitor afterwards (only one program can use the port).
*/

const long BAUD = 115200;                // must equal SERIAL_BAUD in config.py

const uint8_t VIB_PIN    = 2;            // SW-420 DO (must be pin 2 or 3 for the interrupt)
const uint8_t GAS_PIN    = A0;           // MQ-2 AO
const uint8_t LED_PIN    = 8;
const uint8_t BUZZER_PIN = 9;

const bool VIB_ACTIVE_HIGH = true;       // DO goes HIGH on vibration. If your module is reversed set false.

const uint16_t SEND_MS   = 250;          // one data line every 250 ms
const uint8_t  OVERSAMPLE = 8;           // analogRead() calls averaged per sample (taken every 10 ms)

volatile bool vibFlag = false;           // set by the interrupt on every SW-420 pulse
void onVibration() { vibFlag = true; }

uint32_t adcSum = 0;                     // running sum of samples in the current 250 ms window
uint16_t adcCount = 0;
unsigned long lastSample = 0;
unsigned long lastSend = 0;

char cmdBuf[8];
uint8_t cmdLen = 0;

void setup() {
  Serial.begin(BAUD);
  pinMode(VIB_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  attachInterrupt(digitalPinToInterrupt(VIB_PIN), onVibration, VIB_ACTIVE_HIGH ? RISING : FALLING);
}

// Pi -> Uno:  "O10\n"  (O, LED 0/1, buzzer 0/1)
void handleSerial() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (cmdLen >= 3 && cmdBuf[0] == 'O') {
        digitalWrite(LED_PIN, cmdBuf[1] == '1' ? HIGH : LOW);
        digitalWrite(BUZZER_PIN, cmdBuf[2] == '1' ? HIGH : LOW);
      }
      cmdLen = 0;
    } else if (cmdLen < sizeof(cmdBuf) - 1) {
      cmdBuf[cmdLen++] = c;
    } else {
      cmdLen = 0;                        // garbage: start over
    }
  }
}

int readGasAveraged() {
  uint16_t sum = 0;                      // 8 x 1023 fits in 16 bits
  for (uint8_t i = 0; i < OVERSAMPLE; i++) sum += analogRead(GAS_PIN);
  return sum / OVERSAMPLE;
}

void loop() {
  handleSerial();
  unsigned long now = millis();

  if (now - lastSample >= 10) {          // one gas sample every 10 ms
    lastSample = now;
    adcSum += readGasAveraged();
    adcCount++;
  }

  if (now - lastSend >= SEND_MS) {
    lastSend = now;

    int gas = adcCount ? (int)(adcSum / adcCount) : readGasAveraged();
    adcSum = 0;
    adcCount = 0;

    noInterrupts();
    bool vib = vibFlag;                  // any pulse since the last line?
    vibFlag = false;
    interrupts();
    if (digitalRead(VIB_PIN) == (VIB_ACTIVE_HIGH ? HIGH : LOW)) vib = true;   // still vibrating right now

    Serial.print("D,");
    Serial.print(gas);
    Serial.print(',');
    Serial.print(vib ? 1 : 0);
    Serial.print(',');
    Serial.println(now / 1000UL);
  }
}
