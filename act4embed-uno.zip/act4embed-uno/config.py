"""
Edit this file to match YOUR setup and email account.
The sensors, LED and buzzer are wired to an Arduino Uno (pins are set in arduino/sensor_node/sensor_node.ino);
the Uno is plugged into the Raspberry Pi 5 with a USB cable.
"""
import os

# ---------------- Mode ----------------
# True  = fake sensor data (test the website on any PC, no hardware needed)
# False = real sensors. On a PC (not a Raspberry Pi) with no Arduino plugged in it
#         switches to simulation automatically and shows a banner.
SIMULATE = False

# ---------------- Arduino Uno (USB serial) ----------------
# The Uno reads the MQ-2 (A0) and the SW-420 (D2) and drives the LED (D8) and buzzer (D9).
# The Pi decides when to alarm and tells the Uno to switch the LED / buzzer on or off.
SERIAL_PORT = "auto"          # "auto" finds the Uno; or set it yourself, e.g. "/dev/ttyACM0"
SERIAL_BAUD = 115200          # must equal BAUD in the Arduino sketch
SERIAL_TIMEOUT = 5            # seconds without a packet before the Arduino is reported as disconnected
ADC_REF_VOLTS = 5.0           # the Uno ADC is 10-bit (0-1023) at 5 V: no voltage divider is needed

# ---------------- Alarm logic ----------------
DEFAULT_GAS_THRESHOLD = 400   # 0-1023 ADC counts. Change it on the dashboard.
WARMUP_SECONDS = 120          # gas alarms are ignored while the MQ-2 heats up
VIB_ALARM_HOLD = 60           # a vibration alarm turns off this many seconds after it STARTED (or on Reset alarm)
VIB_RESET_GRACE = 3           # (no longer used since patch11, see VIB_SETTLE_SECONDS)
VIB_SETTLE_SECONDS = 2        # after Reset alarm or the 1-minute timeout, the sensor must be quiet this long before it can alarm again
VIB_QUIET_SECONDS = 5          # the 1-minute countdown only starts once the sensor has been quiet this long;
                                # any new vibration before or during the countdown restarts this wait
GAS_REARM_RATIO = 0.9         # after Reset alarm, gas must fall below this fraction of the threshold...
GAS_REARM_SECONDS = 5         # ...and stay there this many seconds before it can alarm again
VIB_HOLD_SECONDS = 3          # keep "vibration detected" on screen this long
SAMPLE_INTERVAL = 0.5         # seconds between sensor reads
LOG_INTERVAL = 2              # seconds between database log entries
ALERT_MIN_GAP = 10            # min seconds between two logged alerts
GRAPH_POINTS = 7200          # points kept for the live graphs (7200 x 0.5s = 1 hour); the Live page shows 2 min at 1x zoom and scrolls back
RETENTION_DAYS = 30           # old log rows are deleted after this many days

# ---------------- Email alerts (smtplib) ----------------
EMAIL_ENABLED = False         # set True after filling in the settings below
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587               # 587 = STARTTLS, 465 = SSL
SMTP_USER = os.environ.get("SMTP_USER", "arthurleywinleywin@gmail.com")
# Use a Gmail APP PASSWORD (Google Account > Security > 2-Step Verification >
# App passwords), never your real password. Best practice: set it as an
# environment variable instead of typing it here:
#     export SMTP_PASSWORD="abcd efgh ijkl mnop"
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
EMAIL_TO = os.environ.get("EMAIL_TO", "2020-200443@rtu.edu.ph")
EMAIL_COOLDOWN = 300          # at most one alert email per sensor (gas / vibration) every 5 minutes

# ---------------- Web server ----------------
HOST = "0.0.0.0"              # reachable from other devices on the network
PORT = 5000
